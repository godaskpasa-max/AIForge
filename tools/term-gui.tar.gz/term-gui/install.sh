#!/usr/bin/env bash
echo "Установка term-gui..."
# Простейшая "установка" — копирование файлов в /usr/local/bin или в текущую папку
INSTALL_DIR="${HOME}/term-gui-installed"
mkdir -p "$INSTALL_DIR/zig-out/bin"
cp -r zig-out/bin/* "$INSTALL_DIR/zig-out/bin/"
chmod +x "$INSTALL_DIR/zig-out/bin/term-gui"
echo "Установка завершена. Для запуска используйте $INSTALL_DIR/run.sh"
