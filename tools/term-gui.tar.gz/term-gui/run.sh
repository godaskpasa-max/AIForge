#!/usr/bin/env bash
# Переходим в папку скрипта и запускаем бинарник
cd "$(dirname "$0")"
zig-out/bin/term-gui
